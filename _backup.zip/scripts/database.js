
burningseries.data = {
  _add_imdb(imdb) {
  },

  add(...args) { return this._add_imdb(args) },
}
