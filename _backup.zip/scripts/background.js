
chrome.commands.onCommand.addListener(command => {
  console.log("onCommand event received for message: ", command)
})
